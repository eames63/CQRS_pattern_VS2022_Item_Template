﻿using MediatR;
using System.ComponentModel.DataAnnotations;

namespace $rootnamespace$.$fileinputname$.Models;

	public class $fileinputname$LookupViewModel : IRequest
	{



	}

