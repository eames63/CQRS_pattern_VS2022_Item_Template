﻿using FluentValidation;
using $rootnamespace$.$fileinputname$.Models;

namespace $rootnamespace$.$fileinputname$.Validators;

	public class $fileinputname$Validator : AbstractValidator<$fileinputname$ViewModel>
{
    public $fileinputname$Validator()
    {



    }
}

