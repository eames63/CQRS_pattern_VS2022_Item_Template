﻿using Hub.Application.Responses;
namespace $rootnamespace$.$fileinputname$.Command;

	public class Delete$fileinputname$CommandResponse: BaseResponse
{
	public Delete$fileinputname$CommandResponse():base()
	{

	}
}


