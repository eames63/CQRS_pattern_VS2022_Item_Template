﻿using System;
using System.Collections.Generic;
using MediatR;
using $rootnamespace$.$fileinputname$.Models;

namespace $rootnamespace$.$fileinputname$.Queries

	public record Get$fileinputname$ViewModelsQuery() : IRequest <List<$fileinputname$ViewModel>>;


